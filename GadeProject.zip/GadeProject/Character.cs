﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    public abstract class Character : Tile
    {
        protected Character(double x, double y, TileType type) : base(x, y, type)
        {

        }

        protected int Hp { set; get; }
        protected int maxHp {set; get;}
        protected int Damage { set; get; }

        protected double[] vision = new double[4];

        public enum Movement
        {
            NoMovement,
            Up,
            Down,
            Right,
            Left

        }

        override public  virtual void Attack()
        {

        }

        public bool IsDead()
        {
            if(Hp == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public virtual bool CheckRange()
        {

        }
        

        

    }
}
