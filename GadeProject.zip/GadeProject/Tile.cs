﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    public abstract class Tile
    {
        protected double x, y;

        public double X { get; set; }
        public double Y { get; set; }
        public enum TileType
        {
            Hero,
            Enemy,
            Gold,
            Weapon

        }

        public TileType Type { get; set; }


        public Tile(double x, double y, TileType type)
        {
            X = x;
            Y = y;
            Type = type;
        }
    }
}
